<?php

declare(strict_types=1);

namespace Modules\Foundation\Tests\Feature;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Log\Logger as LaravelLogger;
use Illuminate\Support\Facades\Route;
use Modules\Foundation\Application\Contracts\AccessTokenServiceInterface;
use Modules\Foundation\Application\Support\SensitiveDataRedactor;
use Modules\Foundation\Domain\Exceptions\ApiException;
use Modules\Foundation\Domain\ValueObjects\AuthenticatedPrincipal;
use Modules\Foundation\Infrastructure\Logging\RedactSensitiveLogContext;
use Modules\Foundation\Presentation\Http\ApiResponder;
use Modules\Foundation\Presentation\Http\RefreshCookieFactory;
use Monolog\Handler\TestHandler;
use Monolog\Logger as MonologLogger;
use RuntimeException;
use Symfony\Component\HttpFoundation\Response;
use Tests\TestCase;

final class ApiFoundationTest extends TestCase
{
    public function test_success_envelope_and_correlation_are_propagated(): void
    {
        $correlationId = '887726632';
        $this->withHeader('X-Correlation-ID', $correlationId)->getJson('/api/v1/foundation/success')->assertOk()->assertHeader('X-Correlation-ID', $correlationId)->assertExactJson(['data' => ['ok' => true], 'meta' => [], 'correlation_id' => $correlationId]);
    }

    public function test_http_is_allowed_only_by_the_explicit_local_exception(): void
    {
        config()->set('chabok.branch_panel.local_http_allowed', false);
        $this->getJson('/api/v1/foundation/success')->assertStatus(403)->assertJsonPath('error_code', 'FORBIDDEN');
        $this->getJson('https://localhost/api/v1/foundation/success')->assertOk();
    }

    public function test_internal_staging_http_requires_explicit_opt_in_and_production_never_allows_it(): void
    {
        $originalEnvironment = $this->app['env'];
        try {
            $this->app['env'] = 'staging';
            config()->set('chabok.branch_panel.local_http_allowed', true);
            $this->getJson('/api/v1/foundation/success')->assertOk();
            config()->set('chabok.branch_panel.local_http_allowed', false);
            $this->getJson('/api/v1/foundation/success')->assertStatus(403)->assertJsonPath('error_code', 'FORBIDDEN');
            $this->app['env'] = 'production';
            config()->set('chabok.branch_panel.local_http_allowed', true);
            $this->getJson('/api/v1/foundation/success')->assertStatus(403)->assertJsonPath('error_code', 'FORBIDDEN');
        } finally {
            $this->app['env'] = $originalEnvironment;
            config()->set('chabok.branch_panel.local_http_allowed', true);
        }
    }

    public function test_invalid_correlation_and_node_headers_use_validation_envelope(): void
    {
        $this->withHeader('X-Correlation-ID', 'invalid header!')->getJson('/api/v1/foundation/success')->assertStatus(422)->assertJsonPath('error_code', 'VALIDATION_ERROR')->assertJsonStructure(['message', 'field_errors' => ['X-Correlation-ID'], 'details', 'correlation_id']);
        $this->flushHeaders();
        // The test client sends "Accept-Language: en-us,en;q=0.5", so the language is asked for explicitly here.
        $this->withHeaders(['X-Node-Id' => 'invalid header!', 'Accept-Language' => 'fa'])->getJson('/api/v1/foundation/context')
            ->assertStatus(422)->assertJsonPath('error_code', 'VALIDATION_ERROR')
            ->assertJsonPath('locale', 'fa')->assertHeader('Content-Language', 'fa')
            ->assertJsonPath('field_errors.X-Node-Id.0', 'مقدار هدر X-Node-Id باید یک عدد صحیح مثبت باشد.');
        $this->flushHeaders();
        $this->withHeaders(['X-Node-Id' => 'invalid header!', 'Accept-Language' => 'en'])->getJson('/api/v1/foundation/context')
            ->assertStatus(422)->assertJsonPath('locale', 'en')
            ->assertJsonPath('field_errors.X-Node-Id.0', 'The X-Node-Id field must be a positive integer.');
    }

    public function test_node_context_never_establishes_tenant_context(): void
    {
        $nodeId = '1802929457';
        $this->withHeader('X-Node-Id', $nodeId)->getJson('/api/v1/foundation/context')->assertOk()->assertJsonPath('data.node_id', $nodeId)->assertJsonPath('data.tenant_id', null);
    }

    public function test_exact_origin_and_credentialed_cors_are_allowlisted(): void
    {
        $this->withHeader('Origin', 'http://localhost:5173')->postJson('/api/v1/foundation/origin')->assertOk()->assertHeader('Access-Control-Allow-Origin', 'http://localhost:5173')->assertHeader('Access-Control-Allow-Credentials', 'true');
        $this->flushHeaders();
        $this->postJson('/api/v1/foundation/origin')->assertStatus(403)->assertJsonPath('error_code', 'ORIGIN_NOT_ALLOWED');
        $this->flushHeaders();
        $this->withHeader('Origin', 'https://localhost.attacker.example')->postJson('/api/v1/foundation/origin')->assertStatus(403)->assertHeaderMissing('Access-Control-Allow-Origin');
        $this->flushHeaders();
        $this->call('OPTIONS', '/api/v1/foundation/origin', server: ['HTTP_ORIGIN' => 'http://localhost:4173', 'HTTP_ACCESS_CONTROL_REQUEST_METHOD' => 'POST'])->assertStatus(204)->assertHeader('Access-Control-Allow-Origin', 'http://localhost:4173');
    }

    public function test_validation_and_unexpected_exceptions_are_safe(): void
    {
        $this->postJson('/api/v1/foundation/validate', [])->assertStatus(422)->assertJsonPath('error_code', 'VALIDATION_ERROR')->assertJsonStructure(['field_errors' => ['name']]);
        $this->getJson('/api/v1/foundation/failure')->assertStatus(500)->assertJsonPath('error_code', 'INTERNAL_SERVER_ERROR')->assertJsonMissing(['message' => 'internal secret must not escape']);
    }

    public function test_refresh_cookie_is_secure_http_only_lax_and_clearable(): void
    {
        $factory = $this->app->make(RefreshCookieFactory::class);
        $cookie = $factory->create('opaque-token');
        $clear = $factory->clear();
        self::assertSame('chabok_refresh', $cookie->getName());
        self::assertSame('/api/v1/auth', $cookie->getPath());
        self::assertTrue($cookie->isSecure());
        self::assertTrue($cookie->isHttpOnly());
        self::assertSame('lax', $cookie->getSameSite());
        self::assertTrue($clear->isSecure());
        self::assertTrue($clear->isHttpOnly());
        self::assertSame('lax', $clear->getSameSite());
        self::assertStringContainsString('Max-Age=0', (string) $clear);
    }

    public function test_forced_password_session_is_restricted_to_the_allowlist(): void
    {
        $this->getJson('/api/v1/foundation/forced')->assertStatus(403)->assertJsonPath('error_code', 'PASSWORD_CHANGE_REQUIRED');
        $this->postJson('/api/v1/foundation/change-password')->assertOk()->assertJsonPath('data.allowed', true);
    }

    public function test_access_tokens_are_signed_short_lived_and_safely_rejected(): void
    {
        $service = $this->app->make(AccessTokenServiceInterface::class);
        $issued = $service->issue(new AuthenticatedPrincipal(userId: '1275327223', sessionId: '13480857', hqId: '28294251', mustChangePassword: true));
        $claims = $service->decode($issued->token);
        self::assertSame(300, $issued->expiresIn);
        self::assertSame('1275327223', $claims->userId);
        self::assertTrue($claims->mustChangePassword);
        $this->expectException(ApiException::class);
        $service->decode($issued->token.'tampered');
    }

    public function test_sensitive_values_are_redacted_from_context_and_messages(): void
    {
        $context = SensitiveDataRedactor::context(['password' => 'secret', 'nested' => ['refresh_token' => 'opaque', 'safe' => 'value']]);
        $message = SensitiveDataRedactor::message('Authorization=Bearer abc.def.ghi password=hunter2');
        self::assertSame('[REDACTED]', $context['password']);
        self::assertSame('[REDACTED]', $context['nested']['refresh_token']);
        self::assertSame('value', $context['nested']['safe']);
        self::assertStringNotContainsString('abc.def.ghi', $message);
        self::assertStringNotContainsString('hunter2', $message);
    }

    public function test_laravel_log_tap_redacts_runtime_records(): void
    {
        $handler = new TestHandler;
        $monolog = new MonologLogger('redaction-test');
        $monolog->pushHandler($handler);
        $logger = new LaravelLogger($monolog);
        (new RedactSensitiveLogContext)($logger);
        $logger->info('Authorization=Bearer abc.def.ghi password=hunter2', ['refresh_token' => 'opaque-refresh-secret', 'safe' => 'value']);
        $records = $handler->getRecords();
        self::assertCount(1, $records);
        $serialized = json_encode(['message' => $records[0]->message, 'context' => $records[0]->context], JSON_THROW_ON_ERROR);
        self::assertStringContainsString('[REDACTED]', $serialized);
        self::assertStringContainsString('value', $serialized);
        self::assertStringNotContainsString('abc.def.ghi', $serialized);
        self::assertStringNotContainsString('hunter2', $serialized);
        self::assertStringNotContainsString('opaque-refresh-secret', $serialized);
    }

    protected function setUp(): void
    {
        parent::setUp();
        $this->app->instance(\Modules\Foundation\Application\Contracts\SecurityMetricRecorderInterface::class, $this->createStub(\Modules\Foundation\Application\Contracts\SecurityMetricRecorderInterface::class));
        $this->app['router']->aliasMiddleware('test.principal', ForcedPrincipal::class);
        Route::middleware('api')->prefix('api/v1')->group(function (): void {
            Route::get('/foundation/success', fn (Request $request) => ApiResponder::success($request, ['ok' => true]));
            Route::get('/foundation/context', fn (Request $request) => ApiResponder::success($request, ['node_id' => $request->attributes->get('node_id'), 'tenant_id' => $request->attributes->get('tenant_id')]));
            Route::post('/foundation/origin', fn (Request $request) => ApiResponder::success($request, ['accepted' => true]))->middleware('origin.exact');
            Route::options('/foundation/origin', fn () => response('', 204));
            Route::post('/foundation/validate', function (Request $request) {
                $request->validate(['name' => ['required', 'string']]);

                return ApiResponder::success($request, ['valid' => true]);
            });
            Route::get('/foundation/failure', fn () => throw new RuntimeException('internal secret must not escape'));
            Route::get('/foundation/forced', fn (Request $request) => ApiResponder::success($request, ['allowed' => true]))->middleware(['test.principal', 'password.changed'])->name('users.index');
            Route::post('/foundation/change-password', fn (Request $request) => ApiResponder::success($request, ['allowed' => true]))->middleware(['test.principal', 'password.changed'])->name('auth.password.change');
        });
    }
}

final class ForcedPrincipal
{
    public function handle(Request $request, Closure $next): Response
    {
        $request->attributes->set('principal', new AuthenticatedPrincipal(userId: '1275327223', sessionId: '13480857', hqId: '28294251', mustChangePassword: true));

        return $next($request);
    }
}
